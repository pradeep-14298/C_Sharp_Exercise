﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 example for carriage return escape sequence(\r)
 */
namespace pradeep
{
    class CLSCRGaa
    {
        public static void Main()
        {
            Console.WriteLine("box\rf");
        }
    }
}
/*
fox
 */
