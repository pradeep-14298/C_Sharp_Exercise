﻿

namespace prja
{
    class Example
    {
        public static void Main()
        {
            System.Console.WriteLine("Hi");
            System.Console.WriteLine(2 + 7);
            System.Console.WriteLine(2 > 7);
        }

    }
}
/*
Hi
9
False
*/