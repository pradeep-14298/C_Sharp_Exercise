﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pradeep
{
    class CLSsimstm
    {
        public static void Main()
        {
            if (false)
            {
                Console.WriteLine("Welcome");
                Console.WriteLine("Visit Again");
            }
            else
                Console.WriteLine("Thanks");
            Console.WriteLine("Hi");

        }
    }
}
/*
Thanks
Hi
 */
