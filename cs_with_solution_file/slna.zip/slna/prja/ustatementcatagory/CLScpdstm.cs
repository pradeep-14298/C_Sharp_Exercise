﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pradeep
{
    class CLScpdstm
    {
        public static void Main()
        {
            if (false)
                Console.WriteLine("Welcome");
                Console.WriteLine("Thanks");
        }
    }
}
/*
Thanks
 */
