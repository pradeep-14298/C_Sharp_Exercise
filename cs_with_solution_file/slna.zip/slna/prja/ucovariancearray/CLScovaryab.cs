﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
example for covariance-array
*/

namespace pradeep.ucovariancearray
{
    class CLScovaryab
    {
        public static void Main()
        {
            //int[] i = { 9, 7, 5 };
            //object[] obj = i;
            
        }

    }
}
/*
Cannot implicitly convert type 'int[]' to 'object[]'	
*/
