﻿using usc=System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 example for how to assign alias name to clas for reduce program coding
 */
namespace pradeep
{
    class CLSANaa
    {
        public static void Main()
        {
            usc.WriteLine("pradeep");
            usc.WriteLine(5 + 5);
        }
    }
}
/*
pradeep
10
 */
