﻿using System;
using System.Data;
using System.Data.SqlClient;
/* how to connect connnectionstring */

namespace pradeep.uadonet
{
    public class CLSSSCnStr
    {
        public static string cnStr = "" +
            "data source=.;" +
            "initial catalog=pradeep;" +
            "integrated security=true;";
    }
}
