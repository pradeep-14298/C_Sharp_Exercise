﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
example for Decimal datatype with suffix m
m stands for money
 */
namespace pradeep
{
    class CLSMISCaa
    {
        public static void Main()
        {
            decimal d = 5.9m;
            Console.WriteLine(d);
        }
    }
}
/*
5.9
 */