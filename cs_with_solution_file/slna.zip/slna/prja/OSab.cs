﻿using System;

namespace pradeep
{
    class OSab
    {
        public static void Main()
        {
            Console.WriteLine("Welcome");
            Console.WriteLine("sun");
            Console.Write("mon");
            Console.Write("tue");
            Console.WriteLine("wed");
            Console.Write("thur");
            Console.WriteLine("fri");
            Console.WriteLine("sat");
            Console.WriteLine("thanks");
        }
    }
}

/*
output
Welcome
sun
montuewed
thurfri
sat
thanks
*/