﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pradeep.upartialclass
{
    partial class CLSPCMathaa
    {
        public int i = 7;
       
        public int uSum(int x,int y)
        {
            return x + y;
        }
    }
}
