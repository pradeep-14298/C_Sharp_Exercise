﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pradeep.upartialclass
{
    partial class CLSPCMathaa
    {
        public int j = 2;
        public void uMinus(int x,int y)
        {
            Console.WriteLine(x - y);
        }
    }
}
