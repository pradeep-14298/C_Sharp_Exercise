﻿using System;

namespace prja
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello pradeep");
        }
    }
}
/*
output
Hello pradeep
*/