﻿using System;

namespace pradeep
{
    class OSaa
    {
        static void Main(string[]args)
        {
            Console.WriteLine(4 + 3 + 8);
        }
    }
}
/* 
 output
 15 
 */
