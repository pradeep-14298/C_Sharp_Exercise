﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pradeep.usetoperator
{
    class CLSSOIaa
    {
        static void Main()
        {
            int[] a ={ 7,1,5};
            int[] b = { 2, 1, 4 };
            a.Intersect(b);
            
        }
        
    }
}
