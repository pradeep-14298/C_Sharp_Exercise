﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pradeep
{
    class CLSCnStr
    {
        public static string forpradeep
        {
            get
            {
                return "data source=.; initial catalog=pradeep;integrated security=true;";
            }
        }
    }
}
