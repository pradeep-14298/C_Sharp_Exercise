﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
how to access datatype like Int32 from CTS?
 */
namespace pradeep
{
    class CLSInt32aa
    {
        public static void Main()
        {
            Int32 i = 5;
            Console.WriteLine(i);
        }
    }
}
/*
5
 */